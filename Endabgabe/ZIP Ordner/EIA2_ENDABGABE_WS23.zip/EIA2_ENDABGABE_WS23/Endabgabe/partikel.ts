/*namespace Particle_Draw{

  let radius: number; 
  public let x: number; 
  public let y: number; 

  let canvas: HTMLCanvasElement;
    let ctx: CanvasRenderingContext2D;

  function drawHeart (); 
  
  drawHeart: void {
      draw(canvas: CanvasRenderingContext2D, particle: IParticle, radius): void {
          const x = -radius,
              y = -radius;
  
          ctx.moveTo(x, y + radius / 2);
          ctx.quadraticCurveTo(x, y, x + radius / 2, y);
          ctx.quadraticCurveTo(x + radius, y, x + radius, y + radius / 2);
          ctx.quadraticCurveTo(x + radius, y, x + (radius * 3) / 2, y);
          ctx.quadraticCurveTo(x + radius * 2, y, x + radius * 2, y + radius / 2);
          ctx.quadraticCurveTo(x + radius * 2, y + radius, x + (radius * 3) / 2, y + (radius * 3) / 2);
          ctx.lineTo(x + radius, y + radius * 2);
          ctx.lineTo(x + radius / 2, y + (radius * 3) / 2);
          ctx.quadraticCurveTo(x, y + radius, x, y + radius / 2);
          ctx.fillStyle = currentColor;

       draw (); 
  
  }

if 


}*/
